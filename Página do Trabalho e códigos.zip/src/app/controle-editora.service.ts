import { Injectable } from '@angular/core';
import { Editora } from './editora';

@Injectable({
  providedIn: 'root'
})
export class ControleEditoraService {

  // b) vetor de editoras
  editoras: Array<Editora> = [
    { codEditora: 1, nome: 'ExemploDeEditora1' },
    { codEditora: 2, nome: 'ExemploDeEditora2' },
    { codEditora: 3, nome: 'ExemploDeEditora3' }
  ];

  constructor() { }

  // c/d) retorna todas as editoras
  getEditoras(): Array<Editora> {
    return this.editoras;
  }

  // c/e) retorna o nome da editora pelo código
  getNomeEditora(codEditora: number): string {
    const resultado = this.editoras.filter(
      (e) => e.codEditora === codEditora
    );
    return resultado.length > 0 ? resultado[0].nome : '';
  }
}

