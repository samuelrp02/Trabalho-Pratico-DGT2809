export class Livro {
  codigo: number = 0;
  codEditora: number = 0;
  titulo: string = '';
  resumo: string = '';
  autores: string[] = [];
}
